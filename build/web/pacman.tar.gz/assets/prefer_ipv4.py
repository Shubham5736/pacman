import socket

_original_getaddrinfo = socket.getaddrinfo

def ipv4_first(host, port, family=0, type=0, proto=0, flags=0):
    results = _original_getaddrinfo(
        host, port, family, type, proto, flags
    )

    ipv4 = [r for r in results if r[0] == socket.AF_INET]
    ipv6 = [r for r in results if r[0] == socket.AF_INET6]

    return ipv4 + ipv6

socket.getaddrinfo = ipv4_first

import runpy
runpy.run_module("pygbag", run_name="__main__")
